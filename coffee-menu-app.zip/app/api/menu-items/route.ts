// app/api/menu-items/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/lib/firebase-admin'; // Este archivo usa firebase-admin

// Maneja la solicitud GET para obtener productos
export async function GET() {
  try {
    const menuRef = db.collection("menuItems");
    const snapshot = await menuRef.orderBy("category").orderBy("name").get();
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    return NextResponse.json(items);
  } catch (error) {
    console.error("Error fetching menu items:", error);
    return NextResponse.json({ message: "Error fetching menu items" }, { status: 500 });
  }
}

// Maneja la solicitud DELETE para eliminar un producto
export async function DELETE(req: Request) {
  try {
    const { id } = await req.json();
    await db.collection("menuItems").doc(id).delete();
    return NextResponse.json({ message: "Item deleted successfully" });
  } catch (error) {
    console.error("Error deleting menu item:", error);
    return NextResponse.json({ message: "Error deleting item" }, { status: 500 });
  }
}
