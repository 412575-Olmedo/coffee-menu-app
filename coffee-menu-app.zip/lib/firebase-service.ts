// lib/firebase-service.ts

// Image upload functions
export const uploadImage = async (file: File, path: string): Promise<string> => {
  try {
    console.log("[v0] Starting image upload via API:", { fileName: file.name, size: file.size, path })

    const formData = new FormData()
    formData.append("file", file)
    formData.append("path", path)

    const response = await fetch("/api/upload-image", {
      method: "POST",
      body: formData,
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || "Failed to upload image")
    }

    const { url } = await response.json()
    console.log("[v0] Image uploaded successfully via API:", url)

    return url
  } catch (error) {
    console.error("[v0] Error uploading image:", error)
    throw new Error(`Error al subir la imagen: ${error instanceof Error ? error.message : "Error desconocido"}`)
  }
}
