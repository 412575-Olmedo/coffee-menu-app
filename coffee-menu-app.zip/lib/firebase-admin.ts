// lib/firebase-admin.ts
import * as admin from 'firebase-admin';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';

// Obtiene la clave privada desde una variable de entorno
if (typeof process.env.FIREBASE_SERVICE_ACCOUNT_KEY === 'string') {
  const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);

  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    });
  }
}

const db = getFirestore();
const storage = getStorage();

export { db, storage, Timestamp };
